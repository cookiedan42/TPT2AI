Lazy to click through The Perfect Tower 2's Scripting Menu?     
Learn Python instead!