Lazy to click through The Perfect Tower 2's Scripting Menu?     
Learn Python instead! 

Add this to a colab notebook using
```
!pip install git+https://github.com/cookiedan42/TPT2AI.git
```
